import { getMapDictionaries } from './dictionary.js';

// ══════════════════════════════════════════════════════════════
// CONFIGURAÇÃO SUPABASE
// ══════════════════════════════════════════════════════════════
// Por favor preencha estas variáveis com os dados do seu projecto Supabase
const SUPABASE_URL = "SUA_SUPABASE_URL_AQUI"; // Exemplo: https://xyz.supabase.co
const SUPABASE_ANON_KEY = "SUA_SUPABASE_ANON_KEY_AQUI"; // Chave pública anónima

class DakiPraKiApp {
  constructor() {
    this.currentDir = 'pt-ch';
    this.translateTimer = null;
    this.saveMissingTimer = null;
    this.recognition = null;
    this.isRecording = false;

    // Inicializa Dicionários
    const { ptToCh, chToPt, dictionaryCount } = getMapDictionaries();
    this.ptToCh = ptToCh;
    this.chToPt = chToPt;

    // Atualiza Total HTML
    const countEl = document.getElementById("dict-count");
    if (countEl) countEl.textContent = dictionaryCount + " entradas";

    this.initScrollAnimations();
  }

  // ══════════════════════════════════════════════════════════════
  // UTILIDADES
  // ══════════════════════════════════════════════════════════════
  normalize(str) {
    if (!str) return "";
    return str.toLowerCase()
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/[^\w\s]/g, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  escapeHtml(unsafe) {
    return unsafe.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  // ══════════════════════════════════════════════════════════════
  // ESTADO E LÓGICA DE TRADUÇÃO
  // ══════════════════════════════════════════════════════════════
  setLangDir(dir) {
    this.currentDir = dir;
    const isPt = dir === 'pt-ch';

    document.getElementById('btn-lang-pt').classList.toggle('active', isPt);
    document.getElementById('btn-lang-ch').classList.toggle('active', !isPt);

    document.getElementById('lbl-src').textContent = isPt ? "Português" : "Xichangana";
    document.getElementById('lbl-tgt').textContent = isPt ? "Xichangana" : "Português";

    const inp = document.getElementById('inp');
    inp.placeholder = isPt ? "Fale ou digite uma frase em Português..." : "Fale ou digite uma frase em Xichangana...";

    if (this.recognition) {
      this.recognition.lang = isPt ? 'pt-MZ' : 'pt-MZ';
    }

    this.clearAll();
  }

  swapLangDir() {
    this.setLangDir(this.currentDir === 'pt-ch' ? 'ch-pt' : 'pt-ch');
  }

  doTranslation(text) {
    if (!text.trim()) {
      document.getElementById('out').innerHTML = '<span class="result-placeholder">A tradução aparecerá aqui...</span>';
      return;
    }

    const regex = /([\wáçéíóúãõâêîôûàèìòùäëïöüñ]+)|([^a-zA-Z0-9áçéíóúãõâêîôûàèìòùäëïöüñ\s]+)|(\s+)/gi;
    const tokens = text.match(regex) || [];

    const mapDict = this.currentDir === 'pt-ch' ? this.ptToCh : this.chToPt;
    let htmlOut = "";

    let i = 0;
    let missingWordsCount = 0;

    while (i < tokens.length) {
      let matchedLength = 0;
      let translated = null;

      for (let j = tokens.length; j > i; j--) {
        const subTokens = tokens.slice(i, j);
        const rawPhrase = subTokens.join('');
        const normPhrase = this.normalize(rawPhrase);

        if (normPhrase !== "" && mapDict.has(normPhrase)) {
          matchedLength = j - i;
          translated = mapDict.get(normPhrase);
          break;
        }
      }

      if (matchedLength > 0) {
        htmlOut += `<span class="token token-translated">${translated}</span>`;
        i += matchedLength;
      } else {
        if (/[\wáçéíóúãõâêîôûàèìòùäëïöüñ]/i.test(tokens[i])) {
          htmlOut += `<span class="token token-untranslated" title="Palavra não encontrada no dicionário">${this.escapeHtml(tokens[i])}</span>`;
          missingWordsCount++;
        } else {
          htmlOut += this.escapeHtml(tokens[i]);
        }
        i++;
      }
    }

    document.getElementById('out').innerHTML = htmlOut;

    // Se houve palavras que não foram traduzidas, debounce e envia para a DB
    if (missingWordsCount > 0) {
      clearTimeout(this.saveMissingTimer);
      this.saveMissingTimer = setTimeout(() => {
        this.saveMissingPhraseToDB(text);
      }, 2000); // Aguarda o utilizador parar de escrever por 2s
    }
  }

  // ══════════════════════════════════════════════════════════════
  // BASE DE DADOS (Submeter frases não encontradas)
  // ══════════════════════════════════════════════════════════════
  async saveMissingPhraseToDB(phrase) {
    if (!phrase.trim()) return;

    // Evita erro no console caso o utilador não tenha preenchido as keys ainda
    if (SUPABASE_URL === "SUA_SUPABASE_URL_AQUI" || !SUPABASE_ANON_KEY) {
      console.warn("DakiPraKi: Frase não traduzida detectada, mas chaves Supabase não foram configuradas. Frase:", phrase);
      return;
    }

    try {
      // Inserimos a palavra directamente na tabela translation_history (ou numa tabela própria para isto)
      // Conforme o SQL, `translation_history` aceita source_text, translated_text, direction, source_lang
      const data = {
        source_text: phrase.trim(),
        translated_text: "[Não Encontrada]",
        direction: this.currentDir,
        match_type: "missing",
        source_lang: this.currentDir === 'pt-ch' ? 'pt-MZ' : 'ch-MZ',
        was_voice: this.isRecording
      };

      await fetch(`${SUPABASE_URL}/rest/v1/translation_history`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
          'Prefer': 'return=minimal'
        },
        body: JSON.stringify(data)
      });
      console.log("DakiPraKi: Frase registada com sucesso para revisão futura.");
    } catch (error) {
      console.error("DakiPraKi: Erro ao submeter frase para a base de dados:", error);
    }
  }

  handleInput() {
    const text = document.getElementById('inp').value;
    clearTimeout(this.translateTimer);
    this.translateTimer = setTimeout(() => this.doTranslation(text), 50);
  }

  clearAll() {
    document.getElementById('inp').value = '';
    this.doTranslation('');
    document.getElementById('inp').focus();
  }

  copyResult() {
    const outText = document.getElementById('out').innerText;
    if (!outText || outText.includes("A tradução aparecerá aqui...")) return;

    navigator.clipboard.writeText(outText).then(() => {
      const btn = document.getElementById('btn-copy');
      btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="#34c759" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
      setTimeout(() => {
        btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>';
      }, 1500);
    });
  }

  // ══════════════════════════════════════════════════════════════
  // TEXTO PARA VOZ (Altifalantes)
  // ══════════════════════════════════════════════════════════════
  speakText(text, btnId) {
    if (!text || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();

    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'pt-MZ';
    u.rate = 0.9;

    const btn = document.getElementById(btnId);
    if (btn) {
      btn.classList.add('speaking');
      u.onend = () => btn.classList.remove('speaking');
      u.onerror = () => btn.classList.remove('speaking');
    }

    window.speechSynthesis.speak(u);
  }

  speakSource() {
    const text = document.getElementById('inp').value;
    if (text.trim().length > 0) {
      this.speakText(text, 'btn-speak-src');
    }
  }

  speakTarget() {
    const text = document.getElementById('out').innerText;
    if (text && !text.includes("A tradução aparecerá aqui...")) {
      this.speakText(text, 'btn-speak-tgt');
    }
  }

  // ══════════════════════════════════════════════════════════════
  // RECONHECIMENTO DE VOZ
  // ══════════════════════════════════════════════════════════════
  toggleMic() {
    if (this.isRecording) this.stopMic(); else this.startMic();
  }

  startMic() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("O reconhecimento de voz não é suportado pelo seu navegador atual.");
      return;
    }

    const isPt = this.currentDir === 'pt-ch';
    this.recognition = new SpeechRecognition();
    this.recognition.lang = isPt ? 'pt-MZ' : 'pt-MZ';
    this.recognition.continuous = true;
    this.recognition.interimResults = true;

    this.recognition.onstart = () => {
      this.isRecording = true;
      document.getElementById('btn-mic').classList.add('recording');
      document.getElementById('live-badge').classList.add('active');
      document.getElementById('inp').placeholder = "A ouvir...";
    };

    this.recognition.onresult = (e) => {
      let finalTrans = "";
      let interimTrans = "";

      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) finalTrans += e.results[i][0].transcript;
        else interimTrans += e.results[i][0].transcript;
      }

      const inp = document.getElementById('inp');
      if (finalTrans) {
        inp.value += (inp.value.length > 0 ? " " : "") + finalTrans;
        this.handleInput();
      }

      const interimEl = document.getElementById('interim-text');
      interimEl.textContent = interimTrans;
      interimTrans ? interimEl.classList.add('active') : interimEl.classList.remove('active');
    };

    this.recognition.onerror = (e) => {
      console.error("Erro no reconhecimento:", e);
      if (e.error === 'not-allowed') {
        alert("O acesso ao microfone foi negado.");
      }
      this.stopMic();
    };

    this.recognition.onend = () => {
      if (this.isRecording) {
        try { this.recognition.start(); } catch (err) { this.stopMic(); }
      }
    };

    try { this.recognition.start(); } catch (e) { console.error(e); }
  }

  stopMic() {
    this.isRecording = false;
    if (this.recognition) {
      try { this.recognition.stop(); } catch (e) { }
    }

    document.getElementById('btn-mic').classList.remove('recording');
    document.getElementById('live-badge').classList.remove('active');

    const isPt = this.currentDir === 'pt-ch';
    document.getElementById('inp').placeholder = isPt ? "Fale ou digite uma frase em Português..." : "Fale ou digite uma frase em Xichangana...";

    const interimEl = document.getElementById('interim-text');
    interimEl.textContent = "";
    interimEl.classList.remove('active');
  }

  // ══════════════════════════════════════════════════════════════
  // SCROLL ANIMATIONS
  // ══════════════════════════════════════════════════════════════
  initScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry, i) => {
        if (entry.isIntersecting) {
          setTimeout(() => entry.target.classList.add("visible"), i * 150);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });

    document.querySelectorAll("[data-reveal]").forEach(el => observer.observe(el));
  }
}

// Inicializar e Injectar no Window context (necessário para onClick events no HTML serem fáceis)
window.app = new DakiPraKiApp();
